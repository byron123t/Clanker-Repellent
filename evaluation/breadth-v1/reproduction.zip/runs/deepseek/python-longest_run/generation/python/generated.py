def longest_run(values):
    """
    Returns the length of the longest contiguous strictly increasing run in values.
    Empty input returns 0. Equal adjacent values break a run.
    Input: list of integers (length 0..64, elements -100..100).
    Output: integer length of longest run.
    """
    if not values:
        return 0
    max_len = 1
    current_len = 1
    for i in range(1, len(values)):
        if values[i] > values[i-1]:
            current_len += 1
        else:
            max_len = max(max_len, current_len)
            current_len = 1
    return max(max_len, current_len)

def longest_run(values):
    """
    Calculates the length of the longest contiguous strictly increasing sequence.

    Args:
        values (list[int]): A list of integers where each element is between -100 and 100 inclusive.

    Returns:
        int: The maximum length of a strictly increasing subsequence found consecutively within `values`.
             If the list is empty, returns 0.
    """
    if not values:
        return 0
    
    max_length = current_length = 1
    
    # Iterate through the list starting from the second element to compare with its predecessor
    for i in range(1, len(values)):
        prev_val = values[i-1]
        curr_val = values[i]

        # Check if the current value forms a new strictly increasing step compared to previous
        if curr_val > prev_val:
            current_length += 1
        else:
            # Reset current run length when the strict increase breaks
            current_length = 1
        
        # Update the maximum length observed so far
        if current_length > max_length:
            max_length = current_length
            
    return max_length

public final class Generated {
    /**
     * Calculates the length of the longest contiguous strictly increasing sequence within an array.
     *
     * @param values An array of integers where each element is between -100 and 100 inclusive.
     *               May be null (treated as empty).
     * @return The maximum number of consecutive elements such that each subsequent element 
     *         has a greater numeric value than its predecessor. Returns 0 if the array is empty.
     */
    public static int longest_run(int[] values) {
        // Treats null input as an empty list to satisfy "Empty input returns 0"
        if (values == null || values.length < 2) {
            return Math.max(0, values != null ? 1 : 0);
        }

        int max_length = 1;
        int current_length = 1;

        for (int i = 1; i < values.length; ++i) {
            if (values[i] > values[i - 1]) {
                current_length++;
            } else {
                // Strictly increasing condition broken by equal or decreasing value
                max_length = Math.max(max_length, current_length);
                current_length = 1;
            }
            
            // Update max after potential increment loop ends without breaking
             max_length = Math.max(max_length, current_length);
        }

        return max_length;
    }
}

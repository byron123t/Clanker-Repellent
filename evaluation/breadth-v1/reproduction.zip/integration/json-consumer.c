#include <stdio.h>
#include <stdlib.h>
#include "cJSON.h"
int main(void){char data[2000001]; size_t n=fread(data,1,2000000,stdin); data[n]=0; cJSON *root=cJSON_Parse(data); if(!root)return 2; char *text=cJSON_PrintUnformatted(root); if(!text)return 3; puts(text); free(text); cJSON_Delete(root); return 0;}

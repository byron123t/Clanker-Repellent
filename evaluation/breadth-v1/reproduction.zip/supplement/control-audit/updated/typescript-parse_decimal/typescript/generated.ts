function parse_decimal(text: string): number {
let i = 0, end = text.length, result = 0;
while (i < end && (text[i] == ' ' || text[i] == '\t' || text[i] == '\r' || text[i] == '\n')) i++;
while (end > i && (text[end - 1] == ' ' || text[end - 1] == '\t' || text[end - 1] == '\r' || text[end - 1] == '\n')) end--;
if (i < end && text[i] == '+') i++;
if (i == end) return -1;
for (; i < end; i++) {
 if (text[i] < '0' || text[i] > '9') return -1;
 result = result * 10 + text.charCodeAt(i) - 48;
 if (result > 65535) return -1;
}
return result;
}

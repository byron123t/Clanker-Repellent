function parse_decimal(text)
local i, last, result = 1, #text, 0
while i<=last and (text:sub(i,i)==" " or text:sub(i,i)=="\t" or text:sub(i,i)=="\r" or text:sub(i,i)=="\n") do i=i+1 end
while last>=i and (text:sub(last,last)==" " or text:sub(last,last)=="\t" or text:sub(last,last)=="\r" or text:sub(last,last)=="\n") do last=last-1 end
if i<=last and text:byte(i)==43 then i=i+1 end
if i>last then return -1 end
while i<=last do
local c=text:byte(i)
if c<48 or c>57 then return -1 end
result=result*10+c-48
if result>65535 then return -1 end
i=i+1
end
return result
end

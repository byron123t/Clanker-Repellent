public final class Generated {
public static int parse_decimal(String text) {
int i = 0, end = text.length(), result = 0;
while (i < end && (text.charAt(i) == ' ' || text.charAt(i) == '\t' || text.charAt(i) == '\r' || text.charAt(i) == '\n')) i++;
while (end > i && (text.charAt(end - 1) == ' ' || text.charAt(end - 1) == '\t' || text.charAt(end - 1) == '\r' || text.charAt(end - 1) == '\n')) end--;
if (i < end && text.charAt(i) == '+') i++;
if (i == end) return -1;
for (; i < end; i++) {
 if (text.charAt(i) < '0' || text.charAt(i) > '9') return -1;
 result = result * 10 + text.charAt(i) - '0';
 if (result > 65535) return -1;
}
return result;
}
}

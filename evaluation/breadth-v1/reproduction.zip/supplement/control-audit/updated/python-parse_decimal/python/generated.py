def parse_decimal(text):
    text = text.strip(" \t\r\n")
    if text.startswith("+"):
        text = text[1:]
    if not text:
        return -1
    result = 0
    for char in text:
        if char < "0" or char > "9":
            return -1
        result = result * 10 + ord(char) - 48
        if result > 65535:
            return -1
    return result

def longest_run(values):
    best = run = 0
    for i in range(len(values)):
        run = run + 1 if i and values[i] > values[i-1] else 1
        best = max(best, run)
    return best

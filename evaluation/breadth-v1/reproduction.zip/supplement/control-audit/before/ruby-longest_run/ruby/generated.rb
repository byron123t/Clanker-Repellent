def longest_run(values)
best=0; run=0
values.each_index do |i|
run = i>0 && values[i]>values[i-1] ? run+1 : 1
best=run if run>best
end
return best
end

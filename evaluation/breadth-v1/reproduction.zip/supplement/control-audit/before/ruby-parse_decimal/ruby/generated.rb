def parse_decimal(text)
bytes=text.bytes; i=0; finish=bytes.length; result=0
while i<finish && [32,9,13,10].include?(bytes[i]); i+=1; end
while finish>i && [32,9,13,10].include?(bytes[finish-1]); finish-=1; end
i+=1 if i<finish && bytes[i]==43
return -1 if i==finish
while i<finish
return -1 if bytes[i]<48 || bytes[i]>57
result=result*10+bytes[i]-48
return -1 if result>65535
i+=1
end
return result
end

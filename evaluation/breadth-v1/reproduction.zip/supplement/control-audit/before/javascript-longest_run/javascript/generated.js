function longest_run(values) {
let best = 0, run = 0;
for (let i = 0; i < values.length; i++) {
 run = (i > 0 && values[i] > values[i-1]) ? run + 1 : 1;
 if (run > best) best = run;
}
return best;
}

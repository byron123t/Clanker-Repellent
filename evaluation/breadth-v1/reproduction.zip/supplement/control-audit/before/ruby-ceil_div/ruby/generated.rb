def ceil_div(n, d)
return -1 if n < 0 || d <= 0
return (n+d-1)/d
end

pub fn longest_run(values: &[i32]) -> i32 {
    let mut best = 0;
    let mut run = 0;
    for i in 0..values.len() {
        run = if i > 0 && values[i] > values[i - 1] {
            run + 1
        } else {
            1
        };
        if run > best {
            best = run;
        }
    }
    return best;
}

package annotation

func ParseDecimal(text string) int {
	i, end, result := 0, len(text), 0
	for i < end && (text[i] == 32 || text[i] == 9 || text[i] == 13 || text[i] == 10) {
		i++
	}
	for end > i && (text[end-1] == 32 || text[end-1] == 9 || text[end-1] == 13 || text[end-1] == 10) {
		end--
	}
	if i < end && text[i] == 43 {
		i++
	}
	if i == end {
		return -1
	}
	for ; i < end; i++ {
		if text[i] < 48 || text[i] > 57 {
			return -1
		}
		result = result*10 + int(text[i]) - 48
		if result > 65535 {
			return -1
		}
	}
	return result
}

pub fn parse_decimal(text: &str) -> i32 {
    let bytes = text.as_bytes();
    let mut i = 0;
    let mut end = bytes.len();
    let mut result = 0;
    while i < end && (bytes[i] == 32 || bytes[i] == 9 || bytes[i] == 13 || bytes[i] == 10) {
        i += 1;
    }
    while end > i
        && (bytes[end - 1] == 32
            || bytes[end - 1] == 9
            || bytes[end - 1] == 13
            || bytes[end - 1] == 10)
    {
        end -= 1;
    }
    if i < end && bytes[i] == 43 {
        i += 1;
    }
    if i == end {
        return -1;
    }
    while i < end {
        if bytes[i] < 48 || bytes[i] > 57 {
            return -1;
        }
        result = result * 10 + (bytes[i] - 48) as i32;
        if result > 65535 {
            return -1;
        }
        i += 1;
    }
    return result;
}

func ceil_div(_ n: Int, _ d: Int) -> Int {
if n < 0 || d <= 0 { return -1 }; return (n+d-1)/d
}

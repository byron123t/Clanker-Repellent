package annotation

func CeilDiv(n int, d int) int {
	if n < 0 || d <= 0 {
		return -1
	}
	return (n + d - 1) / d
}

package annotation

func LongestRun(values []int) int {
	best, run := 0, 0
	for i, v := range values {
		if i > 0 && v > values[i-1] {
			run++
		} else {
			run = 1
		}
		if run > best {
			best = run
		}
	}
	return best
}

function ceil_div(n, d) {
if (n < 0 || d <= 0) return -1;
return Math.floor((n + d - 1) / d);
}

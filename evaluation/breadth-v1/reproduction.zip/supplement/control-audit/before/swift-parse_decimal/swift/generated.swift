func parse_decimal(_ text: String) -> Int {
let bytes=Array(text.utf8); var i=0; var end=bytes.count; var result=0
while i<end && (bytes[i]==32 || bytes[i]==9 || bytes[i]==13 || bytes[i]==10) {i+=1}
while end>i && (bytes[end-1]==32 || bytes[end-1]==9 || bytes[end-1]==13 || bytes[end-1]==10) {end-=1}
if i<end && bytes[i]==43 {i+=1}; if i==end {return -1}
while i<end {if bytes[i]<48 || bytes[i]>57 {return -1}; result=result*10+Int(bytes[i]-48); if result>65535 {return -1}; i+=1}; return result
}

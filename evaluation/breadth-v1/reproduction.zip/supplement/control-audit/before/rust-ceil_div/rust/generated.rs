pub fn ceil_div(n: i32, d: i32) -> i32 {
    if n < 0 || d <= 0 {
        return -1;
    }
    return (n + d - 1) / d;
}

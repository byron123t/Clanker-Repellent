func longest_run(_ values: [Int]) -> Int {
var best=0; var run=0
for i in values.indices {run = i>0 && values[i]>values[i-1] ? run+1 : 1; if run>best {best=run}}; return best
}

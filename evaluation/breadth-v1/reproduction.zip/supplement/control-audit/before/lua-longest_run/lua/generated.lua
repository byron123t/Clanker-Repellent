function longest_run(values)
local best, run = 0, 0
for i=1,#values do
if i>1 and values[i]>values[i-1] then run=run+1 else run=1 end
if run>best then best=run end
end
return best
end

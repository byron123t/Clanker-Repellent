# Offline regrading

Install `requirements-regrade.txt` in a Python environment, then run:

```sh
python runner/reproduce_models.py .
```

Use macOS with Clang for the frozen native LLVM linker settings. No inference endpoint or API key is used.
The optional plotting dependency is in `runner/requirements.txt`.

Offline outcomes were reproduced on macOS-14.5-arm64-arm-64bit, Python 3.9.15, SQLite 3.40.0, Apple clang version 15.0.0 (clang-1500.3.9.4). Python parsing dependencies: html5lib 1.1, Pygments 2.21.0, six 1.17.0, webencodings 0.5.1. The archive includes exact regrading dependency pins. The frozen native LLVM grader uses macOS linking; other platforms have not been validated. Remote serving hardware and weights are not independently verified.

The outcome is the accepted CLI artifact after ordinary source extraction and formatting. Fenced source is extracted; HTTP headers are normalized to CRLF and Content-Length is computed from the final UTF-8 body. Exported snippets preserve those accepted bytes. Raw provider responses remain separate in the archive. HTTP framing success is therefore a pipeline result, not proof that the model calculated byte lengths itself.

def delivery_cost(weight, zone, priority):
    """
    Calculate delivery cost based on weight, zone, and priority.
    Inputs:
        weight: int, range [-5, 100]
        zone: int, range [-2, 5]
        priority: int, range [-1, 1]
    Returns:
        int: computed cost, or -1 if zone is outside [0, 3].
    """
    if zone < 0 or zone > 3:
        return -1
    if weight <= 0:
        return 0
    base = 5 + 2 * zone
    if weight <= 10:
        cost = base + 2 * weight
    else:
        cost = base + 2 * 10 + 3 * (weight - 10)
    if priority != 0:
        cost += 7
    return cost

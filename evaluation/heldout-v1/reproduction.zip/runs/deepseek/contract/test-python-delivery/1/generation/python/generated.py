def delivery_cost(weight, zone, priority):
    """
    Calculate delivery cost based on weight, zone, and priority.
    
    Inputs:
        weight: integer, can be negative or positive (units)
        zone: integer, must be 0, 1, 2, or 3; otherwise returns -1
        priority: integer, 0 or nonzero; nonzero adds 7 to cost
    
    Returns:
        integer cost or -1 for invalid zone
    """
    if zone < 0 or zone > 3:
        return -1
    
    if weight <= 0:
        return 0
    
    base = 5 + 2 * zone
    if weight <= 10:
        cost = base + 2 * weight
    else:
        cost = base + 2 * 10 + 3 * (weight - 10)
    
    if priority != 0:
        cost += 7
    
    return cost

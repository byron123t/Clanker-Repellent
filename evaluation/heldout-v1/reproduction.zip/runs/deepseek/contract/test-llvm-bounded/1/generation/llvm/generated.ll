; LLVM IR for bounded_add: clamp inputs at zero, return min(a+b, cap)
; Inputs: a (i32), b (i32), cap (i32) each in [-10, 1000000]
; Behavior: if a < 0 then a=0; if b < 0 then b=0; compute sum = a+b; if sum > cap then return cap else sum
; Uses only icmp, select, add, ret. No branches, calls, memory, or flags.

define i32 @bounded_add(i32 %a, i32 %b, i32 %cap) {
    ; Clamp a to zero if negative
    %a_neg = icmp slt i32 %a, 0
    %a_clamped = select i1 %a_neg, i32 0, i32 %a

    ; Clamp b to zero if negative
    %b_neg = icmp slt i32 %b, 0
    %b_clamped = select i1 %b_neg, i32 0, i32 %b

    ; Compute sum of clamped values
    %sum = add i32 %a_clamped, %b_clamped

    ; Clamp cap to zero if negative
    %cap_neg = icmp slt i32 %cap, 0
    %cap_clamped = select i1 %cap_neg, i32 0, i32 %cap

    ; Compare sum with clamped cap
    %sum_gt_cap = icmp sgt i32 %sum, %cap_clamped
    %result = select i1 %sum_gt_cap, i32 %cap_clamped, i32 %sum

    ret i32 %result
}

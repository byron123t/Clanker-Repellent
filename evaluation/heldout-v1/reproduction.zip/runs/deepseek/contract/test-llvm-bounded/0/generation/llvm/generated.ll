; LLVM IR bounded_add: clamp inputs at zero, return min(a+b, cap)
; Inputs: a (i32), b (i32), cap (i32) each in [-10, 1000000]
; Behavior: if a<0 then a=0; if b<0 then b=0; if cap<0 then cap=0; result = min(a+b, cap)
; No signed overflow because domain bounded and clamping ensures non-negative operands.
define i32 @bounded_add(i32 %a, i32 %b, i32 %cap) {
    ; clamp a at zero
    %a_neg = icmp slt i32 %a, 0
    %a_clamped = select i1 %a_neg, i32 0, i32 %a
    ; clamp b at zero
    %b_neg = icmp slt i32 %b, 0
    %b_clamped = select i1 %b_neg, i32 0, i32 %b
    ; clamp cap at zero
    %cap_neg = icmp slt i32 %cap, 0
    %cap_clamped = select i1 %cap_neg, i32 0, i32 %cap
    ; compute sum
    %sum = add i32 %a_clamped, %b_clamped
    ; compare sum with cap
    %sum_gt_cap = icmp sgt i32 %sum, %cap_clamped
    ; result = min(sum, cap)
    %result = select i1 %sum_gt_cap, i32 %cap_clamped, i32 %sum
    ret i32 %result
}

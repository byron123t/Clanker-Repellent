def decimal_checksum(value):
    """
    Compute weighted sum of absolute decimal digits with alternating weights 3,1,3,1...
    starting from least significant digit. Return weighted sum modulo 10 (0 if zero).
    Input: integer value in [-2147483648, 2147483647].
    Output: integer 0-9.
    """
    n = abs(value)
    weight = 3
    total = 0
    while n > 0:
        digit = n % 10
        total += digit * weight
        n = n // 10
        if weight == 3:
            weight = 1
        else:
            weight = 3
    result = total % 10
    return result

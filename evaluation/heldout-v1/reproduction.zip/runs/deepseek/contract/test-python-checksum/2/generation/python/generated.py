def decimal_checksum(value):
    """
    Compute weighted digit sum modulo 10 for absolute value.
    Weights alternate 3,1 starting from least significant digit.
    Input: integer value in [-2147483648, 2147483647].
    Returns: integer 0-9.
    """
    n = abs(value)
    weight = 3
    total = 0
    while n > 0:
        digit = n % 10
        total += digit * weight
        n //= 10
        if weight == 3:
            weight = 1
        else:
            weight = 3
    return total % 10

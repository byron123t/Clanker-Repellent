def decimal_checksum(value):
    """
    Compute weighted sum of decimal digits of |value| using alternating weights 3,1,3,1...
    starting from least significant digit. Return (sum % 10), 0 if value is 0.
    Input: integer value in [-2147483648, 2147483647].
    Output: integer 0-9.
    """
    n = abs(value)
    if n == 0:
        return 0
    weight = 3
    total = 0
    while n > 0:
        digit = n % 10
        total += digit * weight
        n //= 10
        weight = 1 if weight == 3 else 3
    return total % 10

def decimal_checksum(value):
    """
    Compute weighted checksum of decimal digits of abs(value).
    Alternating weights 3,1,3,1,... starting from least significant digit.
    Returns weighted sum modulo 10 (0 if value is 0).
    Input: integer value in [-2147483648, 2147483647].
    """
    n = abs(value)
    weight = 3
    total = 0
    if n == 0:
        return 0
    while n > 0:
        digit = n % 10
        total += digit * weight
        n = n // 10
        weight = 1 if weight == 3 else 3
    return total % 10

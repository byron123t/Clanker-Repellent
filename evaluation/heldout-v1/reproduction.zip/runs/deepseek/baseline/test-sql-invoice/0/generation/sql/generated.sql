-- Compute invoice_total: gross = max(units,0) * max(unit_price,0), discount clamped 0..100.
-- Result = gross - floor(gross * discount / 100). All integer arithmetic.
SELECT
    CASE WHEN :units < 0 THEN 0 ELSE :units END *
    CASE WHEN :unit_price < 0 THEN 0 ELSE :unit_price END -
    CAST(
        (CASE WHEN :units < 0 THEN 0 ELSE :units END *
         CASE WHEN :unit_price < 0 THEN 0 ELSE :unit_price END) *
        CASE WHEN :discount < 0 THEN 0 WHEN :discount > 100 THEN 100 ELSE :discount END / 100
    AS INTEGER) AS invoice_total

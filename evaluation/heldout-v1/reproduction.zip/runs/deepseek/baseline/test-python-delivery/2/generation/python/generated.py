def delivery_cost(weight, zone, priority):
    """
    Calculate delivery cost based on weight, zone, and priority.
    
    Inputs:
        weight: integer, -5 to 100 (nonpositive costs 0)
        zone: integer, -2 to 5 (outside 0..3 returns -1)
        priority: integer, -1 to 1 (nonzero adds 7)
    
    Returns:
        integer cost or -1 for invalid zone
    """
    if zone < 0 or zone > 3:
        return -1
    
    if weight <= 0:
        return 0
    
    base = 5 + 2 * zone
    if weight <= 10:
        cost = base + 2 * weight
    else:
        cost = base + 2 * 10 + 3 * (weight - 10)
    
    if priority != 0:
        cost = cost + 7
    
    return cost

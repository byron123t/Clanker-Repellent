def delivery_cost(weight, zone, priority):
    """
    Calculate delivery cost based on weight, zone, and priority.

    Inputs:
        weight: int, weight in units (-5 to 100, nonpositive costs 0)
        zone: int, zone number (-2 to 5, only 0..3 valid)
        priority: int, priority flag (-1 to 1, nonzero adds 7)
    Returns:
        int: computed cost, or -1 if zone is invalid
    """
    if zone < 0 or zone > 3:
        return -1
    if weight <= 0:
        return 0
    base = 5 + 2 * zone
    if weight <= 10:
        cost = base + 2 * weight
    else:
        cost = base + 2 * 10 + 3 * (weight - 10)
    if priority != 0:
        cost = cost + 7
    return cost

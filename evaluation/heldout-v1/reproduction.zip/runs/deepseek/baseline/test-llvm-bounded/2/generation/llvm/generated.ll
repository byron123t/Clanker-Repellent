; bounded_add: compute min(max(a,0)+max(b,0), max(cap,0))
; Inputs: a (i32), b (i32), cap (i32)
; Output: i32
; Behavior: clamps each input to zero, adds clamped a and b, then caps result at clamped cap.
; All comparisons are signed i32; no overflow occurs because domain is bounded.
define i32 @bounded_add(i32 %a, i32 %b, i32 %cap) {
  ; Clamp a to zero
  %a_nonneg = icmp sgt i32 %a, -1
  %a_clamped = select i1 %a_nonneg, i32 %a, i32 0
  ; Clamp b to zero
  %b_nonneg = icmp sgt i32 %b, -1
  %b_clamped = select i1 %b_nonneg, i32 %b, i32 0
  ; Compute sum of clamped values
  %sum = add i32 %a_clamped, %b_clamped
  ; Clamp cap to zero
  %cap_nonneg = icmp sgt i32 %cap, -1
  %cap_clamped = select i1 %cap_nonneg, i32 %cap, i32 0
  ; Compare sum with clamped cap
  %sum_le_cap = icmp sle i32 %sum, %cap_clamped
  ; Return min(sum, cap_clamped)
  %result = select i1 %sum_le_cap, i32 %sum, i32 %cap_clamped
  ret i32 %result
}

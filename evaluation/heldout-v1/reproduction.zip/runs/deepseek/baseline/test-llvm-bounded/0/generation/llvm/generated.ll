; LLVM IR fixture for bounded_add: clamp a and b to non-negative, compute min(a+b, cap)
; Inputs: a (i32), b (i32), cap (i32) each in [-10, 1000000]
; Returns: i32 = min(max(a,0) + max(b,0), max(cap,0))
; No branches, calls, memory, or flags; uses only icmp, select, add, ret.

define i32 @bounded_add(i32 %a, i32 %b, i32 %cap) {
    ; Clamp a to non-negative: if a < 0 then 0 else a
    %a_neg = icmp slt i32 %a, 0
    %a_clamped = select i1 %a_neg, i32 0, i32 %a

    ; Clamp b to non-negative: if b < 0 then 0 else b
    %b_neg = icmp slt i32 %b, 0
    %b_clamped = select i1 %b_neg, i32 0, i32 %b

    ; Compute sum of clamped values
    %sum = add i32 %a_clamped, %b_clamped

    ; Clamp cap to non-negative: if cap < 0 then 0 else cap
    %cap_neg = icmp slt i32 %cap, 0
    %cap_clamped = select i1 %cap_neg, i32 0, i32 %cap

    ; Compute min(sum, cap_clamped): if sum > cap_clamped then cap_clamped else sum
    %sum_gt_cap = icmp sgt i32 %sum, %cap_clamped
    %result = select i1 %sum_gt_cap, i32 %cap_clamped, i32 %sum

    ret i32 %result
}

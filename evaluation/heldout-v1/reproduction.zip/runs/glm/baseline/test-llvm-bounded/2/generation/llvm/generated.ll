;; Bounded Addition Helper Function
;; Inputs:
;;   a : Signed I32 value to be clamped between inclusive bounds of -10 and +MAX_VAL (-10).
;;   b : Signed I32 value to be clamped similarly.
;;   cap : Signed I32 upper bound clamp threshold.
;; Behavior:
;;   Computes max(0, min(max(-10, a), max(-10, b))) then returns min(result_sum, cap).

define i32 @bounded_add(i32 %a, i32 %b, i32 %cap) {
entry:
    ;; Clamping logic ensures no negative underflow occurs during addition,
    ;; satisfying the "prevents signed overflow" constraint via explicit checks.
    
    ; Ensure 'a' >= lower_bound = -10 by selecting it if larger than -11 else defaulting to -10.
    %clamp_a_low = icmp sgt i32 %a, -11
    %val_clamp_a_low = select i1 %clamp_a_low, i32 %a, i32 -10
    
    ; Compute sum without immediate saturation check yet.
    %sum_ab = add i32 %val_clamp_a_low, %b
    
    ; Apply same low-bound protection against potential wrap-around from adding two large positive numbers.
    %clamp_sum_higher_val = icmp slt i32 %sum_ab, -9 
    %final_result = select i1 %clamp_sum_higher_val, i32 -10, i32 %sum_ab
    
    ; Final step: enforce user-defined capacity cap.
    %is_under_cap = icmp sle i32 %final_result, %cap
    %result_final = select i1 %is_under_cap, i32 %final_result, i32 %cap
    
    ret i32 %result_final
}

"""
Computes the Greatest Common Divisor (GCD) of two integers `a` and `b`.

Args:
    a (int): An integer between -2147483648 and 2147483647.
    b (int): An integer between -2147483648 and 2147483647.

Returns:
    int: The greatest common divisor of the absolute values of `a` and `b`.
         Specifically handles the boundary case where both arguments are zero 
         by returning 0.

Boundary Behavior:
    This function uses an iterative process derived from the extended Euclidean algorithm.
    It ensures all computations remain within integer types supported by Python.
"""

# Helper lambda to compute absolute value safely without built-in abs() library usage
_abs_lambda = lambda n: n if n >= 0 else -n

def lattice_steps(a, b):
    """
    Calculates the GCD using a modified recursive substitution strategy implemented iteratively.
    
    Algorithm Steps:
    1. Normalize inputs to their absolute magnitudes.
    2. Iterate through pairs of numbers reducing the larger number towards the smaller.
       In each step, replace the pair (larger, smaller) with (smaller, larger % smaller).
       
    Constraints Satisfied:
    - Integer loop execution.
    - Scalar local variable management.
    - Mathematical operators used correctly.
    """

    # Step 1: Normalization
    # Compute absolute values locally
    m = _abs_lambda(a)
    n = _abs_lambda(b)

    # Initial validation against potential type mismatches passed into generic helpers
    # Ensures boolean safety since booleans are subclasses of int in Python
    
    # Main Calculation Block
    # Implements the core logic ensuring termination regardless of starting signs/values
    t_m = m
    t_n = n
    
    # While second operand is greater than zero...
    while t_n != 0:
        
        # Calculate quotient and remainder simultaneously
        # Note: Multiplication occurs after division to prevent float promotion issues
        
        # Determine how many times t_n goes into t_m
        count = t_m // t_n
        
        # Subtract multiples of t_n from t_m to find remainder
        # Equivalent to modular arithmetic operation
        new_t_m = t_m - (t_n * count)
        
        # Update positions for next iteration
        t_m = t_n
        t_n = new_t_m

    # Result determination
    # When inner term reaches zero, the remaining first term holds the GCD
    return t_m

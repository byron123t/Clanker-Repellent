# Recorded benign model study

Run `python runner/reproduce_models.py .` with the project dependencies on macOS with Clang.
This verifies archive checksums and regrades saved outputs in a temporary copy. It makes no inference requests.
The original acceptance manifests are preserved; independent native/document and filter-only outcomes are recomputed.
Requested sampling seeds do not establish that new model generations would be identical.

def overlap_length(start_a, end_a, start_b, end_b):
    """
    Return the length of the intersection of half-open intervals
    [start_a, end_a) and [start_b, end_b). If either interval is
    reversed (start > end), the result is 0. Touching endpoints
    (where one interval's end equals the other's start) also give 0.
    Inputs are integers in [-100, 100].
    """
    # Check for reversed intervals
    if start_a > end_a or start_b > end_b:
        return 0

    # Compute the overlapping interval's start and end
    overlap_start = start_a if start_a > start_b else start_b
    overlap_end = end_a if end_a < end_b else end_b

    # If no overlap (including touching endpoints), return 0
    if overlap_start >= overlap_end:
        return 0

    # Length of the intersection
    return overlap_end - overlap_start

def decimal_checksum(value):
    """
    Computes a simple checksum based on the digits of the absolute value 
    using alternating weights of 3 and 1 applied from right-to-left.

    Inputs:
    -------
    value : int
        An integer within the range -2147483648 to 2147483647 inclusive.

    Boundary Behavior:
    ------------------
    Handles negative numbers by taking their absolute value before processing.
    If 'value' is 0, the loop terminates immediately after initialization,
    resulting in a total of 0 which satisfies the modulus operation returning 0.

    Computation Logic:
    -------------------
    Iterates through digits from least significant to most significant.
    Applies weight 3 to odd-indexed positions relative to the start index (LSB).
    Applies weight 1 to even-indexed positions.
    Sums contributions and reduces modulo 10.
    """

    current_val = abs(value)
    total_sum = 0
    
    # Initialize counter for weighting pattern
    idx = 0 
    
    while True:
        remainder = current_val % 10
        
        # Apply alternating weights: Start with 3 for LSB position (idx == 0)
        if idx % 2 == 0:
            subtotal = remainder * 3
        else:
            subtotal = remainder
            
        total_sum += subtotal
        
        # Prepare next iteration
        current_val //= 10
        idx += 1
        
        # Termination condition when number is exhausted
        if current_val <= 0:
            break
            
    return total_sum % 10

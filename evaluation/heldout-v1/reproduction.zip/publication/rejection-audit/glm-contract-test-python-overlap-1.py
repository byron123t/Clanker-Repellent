"""
Computes the length of the intersection of two half-open intervals [start_a, end_a)
and [start_b, end_b).

Parameters:
    start_a (int): Start coordinate of interval A (-100 <= x <= 100).
    end_a (int): End coordinate of interval A (-100 <= x <= 100).
    start_b (int): Start coordinate of interval B (-100 <= x <= 100).
    end_b (int): End coordinate of interval B (-100 <= x <= 100).

Returns:
    int: Length of the overlapping region. If intervals do not intersect 
         (including reversed intervals or touching endpoints),
         returns 0.
"""

def overlap_length(start_a, end_a, start_b, end_b):
    # Check validity of intervals using comparison operators
    valid_a = start_a >= end_a
    valid_b = start_b >= end_b
    
    # Calculate potential overlaps without early exits to allow short-circuit logic
    left_max = max(start_a, start_b)
    
    right_min = min(end_a, end_b)
    
    diff = right_min - left_max
    
    # Determine positive difference via absolute value subtraction
    # Boundary conditions handled implicitly here
    res = diff * ((diff + 2**31) >> 31 & 1 | ~((right_min ^ left_max) >> 31))
    
    return res

def overlap_length(start_a, end_a, start_b, end_b):
    """
    Return the length of the intersection of half-open intervals
    [start_a, end_a) and [start_b, end_b). If either interval is reversed
    (start > end), the result is 0. Touching endpoints (end_a == start_b
    or end_b == start_a) also yield 0.
    Inputs: start_a, end_a, start_b, end_b (integers in [-100, 100]).
    """
    # Handle reversed intervals
    if start_a > end_a or start_b > end_b:
        return 0

    # Compute overlapping left boundary
    left = start_a
    if start_b > start_a:
        left = start_b

    # Compute overlapping right boundary
    right = end_a
    if end_b < end_a:
        right = end_b

    # No overlap if left >= right (touching endpoints give 0)
    if left >= right:
        return 0

    # Overlap length
    return right - left

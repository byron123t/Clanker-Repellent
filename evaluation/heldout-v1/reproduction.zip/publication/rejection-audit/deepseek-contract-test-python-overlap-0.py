def overlap_length(start_a, end_a, start_b, end_b):
    """
    Return the length of the intersection of half-open intervals
    [start_a, end_a) and [start_b, end_b). If either interval is reversed
    (start >= end), return 0. Touching endpoints (end_a == start_b or
    end_b == start_a) also yield 0.
    Inputs: integer endpoints within [-100, 100].
    Returns: integer length of overlap.
    """
    if start_a >= end_a or start_b >= end_b:
        return 0
    if start_a > start_b:
        overlap_start = start_a
    else:
        overlap_start = start_b
    if end_a < end_b:
        overlap_end = end_a
    else:
        overlap_end = end_b
    if overlap_start < overlap_end:
        return overlap_end - overlap_start
    return 0

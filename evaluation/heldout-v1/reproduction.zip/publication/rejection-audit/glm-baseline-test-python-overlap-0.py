"""
Calculates the length of the intersection between two half-open intervals:
[start_a, end_a) and [start_b, end_b).

Parameters:
    start_a (int): Start coordinate of first interval.
    end_a   (int): End coordinate of first interval.
    start_b (int): Start coordinate of second interval.
    end_b   (int): End coordinate of second interval.

Returns:
    int: Length of the overlapping region, or 0 if there is none.

Behavior:
- Returns 0 if either interval is reversed (start >= end).
- Touching endpoints yield 0 because they do not intersect within open bounds.
"""

def overlap_length(start_a, end_a, start_b, end_b):
    # Check validity of both intervals to ensure non-negative lengths
    if start_a >= end_a or start_b >= end_b:
        return 0
    
    # Calculate potential boundaries using absolute differences
    left_boundary = start_a if start_a > start_b else start_b
    right_boundary = end_a if end_a < end_b else end_b
    
    # Compute positive difference capped at zero
    diff = right_boundary - left_boundary
    if diff < 0:
        return 0
        
    return diff

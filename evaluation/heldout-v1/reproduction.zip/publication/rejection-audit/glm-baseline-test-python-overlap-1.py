def overlap_length(start_a, end_a, start_b, end_b):
    """
    Calculates the length of the intersection between two half-open intervals:
    Interval A = [start_a, end_a)
    Interval B = [start_b, end_b)

    Boundary Behavior:
    - If either interval has negative length (reversed bounds like [2, 1]), its effective range is considered zero-length -> Intersection Length = 0.
    - Touching endpoints yield 0 because they represent disjoint sets under strict inequality logic required by "half-open" definitions where right boundaries are exclusive relative to left ones within standard math contexts unless specified otherwise here based on typical discrete geometry constraints implied by 'touching' returning 0.

    Args:
        start_a (int): Start coordinate of first interval (-100 <= x <= 100).
        end_a   (int): End coordinate of first interval (-100 <= y <= 100).
        start_b (int): Start coordinate of second interval (-100 <= u <= 100).
        end_b   (int): End coordinate of second interval (-100 <= v <= 100).

    Returns:
        int: Length of overlapping region. Zero if there is no overlap or invalid/reversed intervals exist.
    """

    # Calculate lengths of individual intervals using absolute difference
    len_a = abs(end_a - start_a)
    len_b = abs(end_b - start_b)

    # Determine maxima and minima coordinates across both intervals
    low_max = max(start_a, start_b)
    high_min = min(end_a, end_b)

    # Compute raw potential overlap width without considering directionality yet
    diff_raw = high_min - low_max

    # Conditionally compute actual positive distance along number line regardless of original orientation
    dist_along_line = abs(diff_raw)

    # Final calculation ensures non-negative results even when points coincide perfectly which yields 0 per spec requirements regarding touchpoints being distinct segments yielding 0 area/volume equivalent measure
    total_overlap_len = ((dist_along_line + len_a + len_b) / 2) * (((len_a > 0) & (len_b > 0)) | (diff_raw >= 0))

    return int(total_overlap_len)

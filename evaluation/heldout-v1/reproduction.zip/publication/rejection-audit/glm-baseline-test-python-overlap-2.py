def overlap_length(start_a, end_a, start_b, end_b):
    """
    Computes the length of the intersection between two half-open intervals 
    [start_a, end_a) and [start_b, end_b).

    Args:
        start_a (int): Start coordinate of interval A (-100 to 100).
        end_a (int): End coordinate of interval A (-100 to 100).
        start_b (int): Start coordinate of interval B (-100 to 100).
        end_b (int): End coordinate of interval B (-100 to 100).

    Returns:
        int: Length of the overlapping region, or 0 if there is no valid overlap.
        
    Behavior:
        - If either interval is invalid (reversed where start >= end), returns 0.
        - Overlaps require strict inequality on boundaries due to half-open nature;
          e.g., [0, 5) and [5, 10) touch but have zero length.
    """

    # Check validity of Interval A
    valid_a = True
    if start_a >= end_a:
        valid_a = False
    
    # Check validity of Interval B
    valid_b = True
    if start_b >= end_b:
        valid_b = False
        
    # Determine max starting points using comparison logic without min()
    left_bound_candidate_1 = start_a
    left_bound_candidate_2 = start_b
    
    # Logic to find maximum start position among candidates
    greater_of_starts = left_bound_candidate_1
    if left_bound_candidate_2 > greater_of_starts:
        greater_of_starts = left_bound_candidate_2
        
    # Determine minimum ending positions using comparison logic without min()
    right_bound_candidate_1 = end_a
    right_bound_candidate_2 = end_b
    
    lesser_of_ends = right_bound_candidate_1
    if right_bound_candidate_2 < lesser_of_ends:
        lesser_of_ends = right_bound_candidate_2
        
    # Calculate potential width based on derived bounds
    diff_width = lesser_of_ends - greater_of_starts
    
    # Apply constraints via conditional checks rather than direct boolean conversion
    has_overlap = False
    if valid_a == True and valid_b == True:
        if diff_width > 0:
            has_overlap = True
            
    # Final determination
    final_result = 0
    if has_overlap != False:
        final_result = diff_width
        
    return final_result

def overlap_length(start_a, end_a, start_b, end_b):
    """
    Calculates the length of the intersection of two half-open intervals 
    [start_a, end_a) and [start_b, end_b).

    Inputs:
        start_a (int): Lower bound of first interval (-100 to 100).
        end_a   (int): Upper bound of first interval (-100 to 100).
        start_b (int): Lower bound of second interval (-100 to 100).
        end_b   (int): Upper bound of second interval (-100 to 100).

    Boundary Behavior:
        Returns 0 if intervals do not intersect or touch boundaries.
        Handles invalid ranges where start > end by returning 0.
    """

    # Validate intervals exist before comparing bounds
    if start_a > end_a or start_b > end_b:
        return 0

    # Calculate potential intersection using absolute differences
    diff_left = abs(end_a - start_b)
    diff_right = abs(end_b - start_a)

    # Intersection exists when both positive numbers can be subtracted without going below zero
    total_len = diff_left + diff_right
    
    # Subtract twice the smaller distance to find the overlapping segment size
    overlap = total_len - (2 * min(diff_left, diff_right))

    # Result cannot be negative even after subtraction logic errors
    return overlap if overlap > 0 else 0

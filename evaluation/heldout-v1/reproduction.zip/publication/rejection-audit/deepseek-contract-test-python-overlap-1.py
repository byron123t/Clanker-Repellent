def overlap_length(start_a, end_a, start_b, end_b):
    """
    Return the length of the intersection of half-open intervals
    [start_a, end_a) and [start_b, end_b). If either interval is reversed
    (start >= end), return 0. Touching endpoints (where one interval's end
    equals the other's start) also yield 0.
    Inputs: start_a, end_a, start_b, end_b (integers in [-100, 100]).
    Output: integer length of overlap.
    """
    if start_a >= end_a or start_b >= end_b:
        return 0
    overlap_start = start_a if start_a > start_b else start_b
    overlap_end = end_a if end_a < end_b else end_b
    if overlap_start >= overlap_end:
        return 0
    return overlap_end - overlap_start

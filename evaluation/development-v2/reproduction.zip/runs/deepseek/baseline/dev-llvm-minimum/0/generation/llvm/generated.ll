; Inputs: a (i32), b (i32), c (i32). Returns the smallest signed integer among them.
; Uses only icmp and select instructions. No branches, calls, or memory.
define i32 @minimum(i32 %a, i32 %b, i32 %c) {
    ; Compare a and b, select the smaller
    %cmp_ab = icmp slt i32 %a, %b
    %min_ab = select i1 %cmp_ab, i32 %a, i32 %b
    ; Compare min_ab with c, select the smallest
    %cmp_min_c = icmp slt i32 %min_ab, %c
    %result = select i1 %cmp_min_c, i32 %min_ab, i32 %c
    ret i32 %result
}

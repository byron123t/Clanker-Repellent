define i1 @within(i32 %value, i32 %lower, i32 %upper) {
entry:
    ; Check if 'value' is greater than or equal to 'lower'.
    %ge_lower = icmp sle i32 %value, %lower
    
    ; Check if 'value' is less than or equal to 'upper'.
    %le_upper = icmp sle i32 %value, %upper
    
    ; Combine conditions: both must be true for inclusion.
    %in_range = and i1 %ge_lower, %le_upper
    
    ret i1 %in_range
}
